﻿namespace Campus02DemoProject.Models
{
    public class Product
    {
        public int ProductId { get; set; }

        public string Bezeichnung { get; set; }
    }
}
