﻿namespace Campus02DemoProject.Models
{
    public class CalcModel
    {
        public int Zahl1 { get; set; }
        public int Zahl2 { get; set; }
    }
}
